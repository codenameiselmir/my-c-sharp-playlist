﻿/*
===========================================================
Lesson 19 - Foreach Loop
Repository: my-c-sharp-playlist
File: my-lecture-notes
===========================================================
*/

/*
In this lesson we will learn:

1) What is foreach loop?
2) Foreach loop syntax
3) When to use foreach
*/

/*
1) What is Foreach Loop?

Foreach loop is used to loop through
elements of an array or collection.

It is simpler and cleaner than a for loop
when we do not need the index number.
*/

/*
2) Foreach Syntax

foreach (dataType variableName in arrayName)
{
    // code
}

- dataType → type of elements inside array
- variableName → temporary variable
- arrayName → array we want to loop
*/

namespace Lesson_19._Foreach_Loop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] cars = { "BMW", "Mustang", "Tesla" };

            /*
            Foreach automatically goes through
            every element in the array.
            */

            foreach (string car in cars)
            {
                Console.WriteLine(car);
            }

            /*
            Important Notes:

            - No index needed.
            - Cannot modify array size.
            - Best for reading values.
            */

            Console.WriteLine();
            Console.WriteLine("Press any key to close...");
            Console.ReadKey();
        }
    }
}